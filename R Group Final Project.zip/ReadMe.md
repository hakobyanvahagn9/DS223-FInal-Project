Hello!

This is how to get to know the work:


The survey to collect the information on the preferances can be found by this link: https://survey101.formr.org/

The survey structure sheets can be found via this link: 

https://docs.google.com/spreadsheets/d/1XvP-soJl7pflrZKUJbwfL4YCix-Qgvocu_OCu9psiB0/edit?fbclid=IwAR0LiR9VbE_qFmAdjXMUohBW7iYZWsEWctyNyIVHxff8fo1ONsF1qBWo3ro#gid=1143492244

It shows the structure via which the actual survey was created.


Look at the file create_survey_questions.rmd to see how the survey was designed.

Look at the analysis_models.Rmd to get acquainted with the logic behind the analysis of the coefficients value of each attribute.

In the dashboard folder you will find the server.R & ui.R files that are required to run the dashboard. 

THe sequence of the executions of the app should be the following: you need to run the analysis_models.Rmd before running the dashboard to generate a dummy data for the analysis. 
